<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "task_manager", 3307);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = null;
$isLogin = isset($_GET['login']);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['register'])) {
        // Registration logic
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
        
        // Validate inputs
        if (empty($email) || empty($password)) {
            $error = "All fields are required";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format";
        } else {
            // Check if email exists
            $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            if ($check_stmt === false) {
                $error = "Database error: " . $conn->error;
            } else {
                $check_stmt->bind_param("s", $email);
                $check_stmt->execute();
                $check_stmt->store_result();
                
                if ($check_stmt->num_rows > 0) {
                    $error = "Email already exists";
                } else {
                    // Create new account
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $insert_stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
                    
                    if ($insert_stmt === false) {
                        $error = "Database error: " . $conn->error;
                    } else {
                        $insert_stmt->bind_param("ss", $email, $hashed_password);
                        
                        if ($insert_stmt->execute()) {
                            $_SESSION['user_id'] = $insert_stmt->insert_id;
                            $_SESSION['user_email'] = $email;
                            header("Location: dashboard.php");
                            exit();
                        } else {
                            $error = "Error creating account: " . $insert_stmt->error;
                        }
                        $insert_stmt->close();
                    }
                }
                $check_stmt->close();
            }
        }
    } elseif (isset($_POST['login'])) {
        // Login logic
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
        
        if (empty($email) || empty($password)) {
            $error = "All fields are required";
        } else {
            $stmt = $conn->prepare("SELECT id, email, password FROM users WHERE email = ?");
            if ($stmt === false) {
                $error = "Database error: " . $conn->error;
            } else {
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 1) {
                    $user = $result->fetch_assoc();
                    if (password_verify($password, $user['password'])) {
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['user_email'] = $user['email'];
                        header("Location: dashboard.php");
                        exit();
                    } else {
                        $error = "Invalid email or password";
                    }
                } else {
                    $error = "Invalid email or password";
                }
                $stmt->close();
            }
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StudySphere | Student Productivity Hub</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Orbitron:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #6C63FF;
            --primary-dark: #5649F0;
            --secondary: #FF6584;
            --accent: #42D7D6;
            --dark: #2D3748;
            --light: #F7FAFC;
            --success: #48BB78;
            --warning: #ED8936;
            --danger: #F56565;
            --tech-blue: #0EA5E9;
            --tech-purple: #8B5CF6;
            --tech-pink: #EC4899;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #0F172A;
            color: white;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            position: relative;
        }
        
        /* Tech Background Elements */
        .tech-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }
        
        .circuit-node {
            position: absolute;
            border-radius: 50%;
            background: rgba(110, 231, 183, 0.1);
            border: 1px solid rgba(110, 231, 183, 0.3);
            animation: pulse 4s infinite alternate;
        }
        
        .circuit-line {
            position: absolute;
            background: linear-gradient(90deg, rgba(110, 231, 183, 0.3), transparent);
            transform-origin: left center;
            height: 1px;
        }
        
        .floating-icon {
            position: absolute;
            opacity: 0.1;
            font-size: 2rem;
            animation: float 15s infinite linear;
        }
        
        @keyframes float {
            0% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-50px) rotate(180deg); }
            100% { transform: translateY(0) rotate(360deg); }
        }
        
        @keyframes pulse {
            0% { transform: scale(1); opacity: 0.3; }
            100% { transform: scale(1.2); opacity: 0.6; }
        }
        
        /* Main Container */
        .auth-container {
            width: 90%;
            max-width: 1200px;
            height: 80vh;
            min-height: 600px;
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(255, 255, 255, 0.1);
            display: flex;
            position: relative;
        }
        
        /* Illustration Side */
        .illustration-side {
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow: hidden;
            background: linear-gradient(135deg, rgba(108, 99, 255, 0.2), rgba(66, 215, 214, 0.2));
        }
        
        .illustration-side::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
            animation: rotate 30s linear infinite;
            z-index: 1;
        }
        
        @keyframes rotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .illustration-content {
            position: relative;
            z-index: 2;
            text-align: center;
            width: 100%;
            max-width: 500px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 30px;
        }
        
        .logo-icon {
            width: 50px;
            height: 50px;
            background: var(--primary);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            transform: rotate(45deg);
        }
        
        .logo-icon i {
            transform: rotate(-45deg);
            font-size: 1.5rem;
        }
        
        .logo-text {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.8rem;
            font-weight: 600;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: 1px;
        }
        
        .illustration-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            background: linear-gradient(90deg, white, var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .illustration-subtitle {
            font-size: 1.1rem;
            opacity: 0.8;
            margin-bottom: 40px;
            line-height: 1.6;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-top: 30px;
        }
        
        .feature-card {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 20px;
            transition: all 0.3s ease;
            backdrop-filter: blur(5px);
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.1);
            box-shadow: 0 10px 20px -10px rgba(108, 99, 255, 0.2);
        }
        
        .feature-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--tech-purple));
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
        }
        
        .feature-title {
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .feature-desc {
            font-size: 0.85rem;
            opacity: 0.7;
            line-height: 1.5;
        }
        
        /* Form Side */
        .form-side {
            width: 400px;
            background: rgba(15, 23, 42, 0.9);
            border-left: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
            overflow: hidden;
        }
        
        .form-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            padding: 50px;
            display: flex;
            flex-direction: column;
            transition: all 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }
        
        .register-container {
            transform: translateX(<?= $isLogin ? '-100%' : '0' ?>);
            opacity: <?= $isLogin ? '0' : '1' ?>;
        }
        
        .login-container {
            transform: translateX(<?= $isLogin ? '0' : '100%' ?>);
            opacity: <?= $isLogin ? '1' : '0' ?>;
        }
        
        .form-header {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .form-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .form-subtitle {
            font-size: 0.9rem;
            opacity: 0.7;
        }
        
        .error-message {
            background: rgba(239, 68, 68, 0.2);
            border: 1px solid var(--danger);
            color: white;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 0.9rem;
            animation: shake 0.5s ease;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20%, 60% { transform: translateX(-5px); }
            40%, 80% { transform: translateX(5px); }
        }
        
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-size: 0.9rem;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.8);
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .form-input {
            width: 100%;
            padding: 14px 14px 14px 42px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            color: white;
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }
        
        .form-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(108, 99, 255, 0.3);
            background: rgba(255, 255, 255, 0.08);
        }
        
        .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.5);
            font-size: 1.1rem;
        }
        
        .password-toggle {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.5);
            cursor: pointer;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }
        
        .password-toggle:hover {
            color: var(--primary);
        }
        
        .password-strength {
            margin-top: 10px;
        }
        
        .strength-meter {
            height: 4px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 5px;
        }
        
        .strength-bar {
            height: 100%;
            width: 0;
            border-radius: 2px;
            transition: width 0.3s ease, background 0.3s ease;
        }
        
        .strength-text {
            font-size: 0.75rem;
            color: rgba(255, 255, 255, 0.5);
        }
        
        .btn {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--tech-purple));
            color: white;
            box-shadow: 0 4px 15px rgba(108, 99, 255, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(108, 99, 255, 0.4);
        }
        
        .btn-primary:active {
            transform: translateY(0);
        }
        
        .auth-switch {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.7);
        }
        
        .auth-link {
            color: var(--primary);
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        
        .auth-link:hover {
            color: var(--accent);
            text-decoration: underline;
        }
        
        /* Floating Books Animation */
        .floating-books {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
            z-index: 1;
        }
        
        .book {
            position: absolute;
            width: 40px;
            height: 50px;
            background: linear-gradient(135deg, var(--tech-blue), var(--tech-purple));
            border-radius: 4px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            animation: floatBook 15s infinite linear;
            opacity: 0.3;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
        }
        
        .book:nth-child(2) {
            background: linear-gradient(135deg, var(--tech-pink), var(--primary));
            animation-delay: 3s;
            top: 20%;
            left: 80%;
        }
        
        .book:nth-child(3) {
            background: linear-gradient(135deg, var(--accent), var(--tech-blue));
            animation-delay: 6s;
            top: 70%;
            left: 10%;
        }
        
        .book:nth-child(4) {
            background: linear-gradient(135deg, var(--secondary), var(--tech-pink));
            animation-delay: 9s;
            top: 40%;
            left: 60%;
        }
        
        @keyframes floatBook {
            0% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-50px) rotate(10deg); }
            100% { transform: translateY(0) rotate(0deg); }
        }
        
        /* Responsive Design */
        @media (max-width: 992px) {
            .auth-container {
                flex-direction: column;
                height: auto;
                min-height: 100vh;
            }
            
            .illustration-side {
                padding: 30px 20px;
            }
            
            .form-side {
                width: 100%;
                border-left: none;
                border-top: 1px solid rgba(255, 255, 255, 0.1);
            }
            
            .form-container {
                padding: 40px;
            }
            
            .features-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 576px) {
            .auth-container {
                width: 100%;
                border-radius: 0;
                min-height: 100vh;
            }
            
            .form-container {
                padding: 30px 20px;
            }
            
            .illustration-title {
                font-size: 2rem;
            }
            
            .form-title {
                font-size: 1.8rem;
            }
        }
    </style>
</head>
<body>
    <!-- Tech Background Elements -->
    <div class="tech-bg" id="techBg"></div>
    
    <!-- Floating Books -->
    <div class="floating-books">
        <div class="book"><i class="fas fa-atom"></i></div>
        <div class="book"><i class="fas fa-laptop-code"></i></div>
        <div class="book"><i class="fas fa-book-open"></i></div>
        <div class="book"><i class="fas fa-flask"></i></div>
    </div>
    
    <!-- Main Auth Container -->
    <div class="auth-container">
        <!-- Illustration Side -->
        <div class="illustration-side">
            <div class="illustration-content">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div class="logo-text">StudySphere</div>
                </div>
                
                <h1 class="illustration-title">Boost Your Academic Productivity</h1>
                <p class="illustration-subtitle">
                    Join thousands of students who are organizing their studies, tracking progress, 
                    and achieving their academic goals with our powerful task management platform.
                </p>
                
                <div class="features-grid">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <h3 class="feature-title">Smart Scheduling</h3>
                        <p class="feature-desc">Plan your study sessions around your classes and commitments</p>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-chart-pie"></i>
                        </div>
                        <h3 class="feature-title">Progress Analytics</h3>
                        <p class="feature-desc">Visualize your study patterns and improvement over time</p>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-bell"></i>
                        </div>
                        <h3 class="feature-title">Reminder System</h3>
                        <p class="feature-desc">Never miss a deadline or important study session again</p>
                    </div>
                    
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3 class="feature-title">Study Groups</h3>
                        <p class="feature-desc">Collaborate with classmates on group projects and assignments</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Form Side -->
        <div class="form-side">
            <!-- Register Form Container -->
            <div class="form-container register-container" id="registerContainer">
                <div class="form-header">
                    <h2 class="form-title">Create Account</h2>
                    <p class="form-subtitle">Start organizing your academic life today</p>
                </div>
                
                <?php if ($error && !isset($_POST['login'])) : ?>
                    <div class="error-message">
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" id="registerForm">
                    <div class="form-group">
                        <label for="regEmail" class="form-label">University Email</label>
                        <div class="input-with-icon">
                            <i class="fas fa-envelope input-icon"></i>
                            <input type="email" id="regEmail" name="email" class="form-input" required 
                                   placeholder="you@university.edu" value="<?= isset($email) ? htmlspecialchars($email) : '' ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="regPassword" class="form-label">Password</label>
                        <div class="input-with-icon">
                            <i class="fas fa-lock input-icon"></i>
                            <input type="password" id="regPassword" name="password" class="form-input" required 
                                   placeholder="Create a strong password">
                            <i class="fas fa-eye password-toggle" id="toggleRegPassword"></i>
                        </div>
                        
                        <div class="password-strength">
                            <div class="strength-meter">
                                <div class="strength-bar" id="strengthBar"></div>
                            </div>
                            <div class="strength-text" id="strengthText">Password strength</div>
                        </div>
                    </div>
                    
                    <button type="submit" name="register" class="btn btn-primary">Get Started</button>
                </form>
                
                <div class="auth-switch">
                    Already have an account? <span class="auth-link" id="showLogin">Sign In</span>
                </div>
            </div>
            
            <!-- Login Form Container -->
            <div class="form-container login-container" id="loginContainer">
                <div class="form-header">
                    <h2 class="form-title">Welcome Back</h2>
                    <p class="form-subtitle">Sign in to continue your productivity journey</p>
                </div>
                
                <?php if ($error && isset($_POST['login'])) : ?>
                    <div class="error-message">
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" id="loginForm">
                    <div class="form-group">
                        <label for="loginEmail" class="form-label">Email Address</label>
                        <div class="input-with-icon">
                            <i class="fas fa-envelope input-icon"></i>
                            <input type="email" id="loginEmail" name="email" class="form-input" required 
                                   placeholder="you@university.edu" value="<?= isset($email) ? htmlspecialchars($email) : '' ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="loginPassword" class="form-label">Password</label>
                        <div class="input-with-icon">
                            <i class="fas fa-lock input-icon"></i>
                            <input type="password" id="loginPassword" name="password" class="form-input" required 
                                   placeholder="Enter your password">
                            <i class="fas fa-eye password-toggle" id="toggleLoginPassword"></i>
                        </div>
                    </div>
                    
                    <button type="submit" name="login" class="btn btn-primary">Sign In</button>
                </form>
                
                <div class="auth-switch">
                    Don't have an account? <span class="auth-link" id="showRegister">Sign Up</span>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Create tech background elements
        function createTechBackground() {
            const container = document.getElementById('techBg');
            container.innerHTML = '';
            
            // Create nodes
            for (let i = 0; i < 15; i++) {
                const node = document.createElement('div');
                node.classList.add('circuit-node');
                
                // Random position
                const posX = Math.random() * 100;
                const posY = Math.random() * 100;
                node.style.left = `${posX}%`;
                node.style.top = `${posY}%`;
                
                // Random size
                const size = Math.random() * 10 + 5;
                node.style.width = `${size}px`;
                node.style.height = `${size}px`;
                
                // Random animation delay
                const delay = Math.random() * 5;
                node.style.animationDelay = `${delay}s`;
                
                container.appendChild(node);
            }
            
            // Create connecting lines (simplified for demo)
            for (let i = 0; i < 8; i++) {
                const line = document.createElement('div');
                line.classList.add('circuit-line');
                
                // Random position and angle
                const startX = Math.random() * 100;
                const startY = Math.random() * 100;
                const length = Math.random() * 15 + 5;
                const angle = Math.random() * 360;
                
                line.style.left = `${startX}%`;
                line.style.top = `${startY}%`;
                line.style.width = `${length}%`;
                line.style.transform = `rotate(${angle}deg)`;
                
                // Random animation
                const duration = Math.random() * 5 + 3;
                line.style.animation = `pulse ${duration}s infinite alternate`;
                
                container.appendChild(line);
            }
            
            // Create floating tech icons
            const icons = ['fa-microchip', 'fa-server', 'fa-code', 'fa-database', 'fa-network-wired'];
            for (let i = 0; i < 8; i++) {
                const icon = document.createElement('i');
                icon.classList.add('fas', icons[Math.floor(Math.random() * icons.length)], 'floating-icon');
                
                // Random position
                const posX = Math.random() * 100;
                const posY = Math.random() * 100;
                icon.style.left = `${posX}%`;
                icon.style.top = `${posY}%`;
                
                // Random animation duration and delay
                const duration = Math.random() * 10 + 10;
                const delay = Math.random() * 5;
                icon.style.animationDuration = `${duration}s`;
                icon.style.animationDelay = `${delay}s`;
                
                container.appendChild(icon);
            }
        }
        
        // Toggle password visibility
        function setupPasswordToggle(toggleId, inputId) {
            const toggle = document.getElementById(toggleId);
            const input = document.getElementById(inputId);
            
            if (toggle && input) {
                toggle.addEventListener('click', function() {
                    const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
                    input.setAttribute('type', type);
                    this.classList.toggle('fa-eye');
                    this.classList.toggle('fa-eye-slash');
                });
            }
        }
        
        // Password strength indicator
        document.getElementById('regPassword')?.addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.getElementById('strengthBar');
            const strengthText = document.getElementById('strengthText');
            
            // Reset
            strengthBar.style.width = '0%';
            strengthBar.style.backgroundColor = '#F56565';
            strengthText.textContent = 'Password strength';
            strengthText.style.color = 'rgba(255, 255, 255, 0.5)';
            
            if (password.length === 0) return;
            
            // Calculate strength
            let strength = 0;
            
            // Length
            if (password.length > 7) strength += 20;
            if (password.length > 12) strength += 10;
            
            // Lowercase
            if (/[a-z]/.test(password)) strength += 15;
            
            // Uppercase
            if (/[A-Z]/.test(password)) strength += 15;
            
            // Numbers
            if (/[0-9]/.test(password)) strength += 15;
            
            // Special characters
            if (/[!@#$%^&*]/.test(password)) strength += 15;
            
            // Repeated characters penalty
            if (/(.)\1/.test(password)) strength -= 10;
            
            // Cap at 100
            strength = Math.min(100, Math.max(0, strength));
            
            // Update UI
            strengthBar.style.width = `${strength}%`;
            
            if (strength < 40) {
                strengthBar.style.backgroundColor = '#F56565';
                strengthText.textContent = 'Weak password';
                strengthText.style.color = '#F56565';
            } else if (strength < 70) {
                strengthBar.style.backgroundColor = '#ED8936';
                strengthText.textContent = 'Medium password';
                strengthText.style.color = '#ED8936';
            } else {
                strengthBar.style.backgroundColor = '#48BB78';
                strengthText.textContent = 'Strong password';
                strengthText.style.color = '#48BB78';
            }
        });
        
        // Switch between login and register forms
        document.getElementById('showLogin')?.addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('registerContainer').style.transform = 'translateX(-100%)';
            document.getElementById('registerContainer').style.opacity = '0';
            document.getElementById('loginContainer').style.transform = 'translateX(0)';
            document.getElementById('loginContainer').style.opacity = '1';
            window.history.pushState(null, '', '?login');
        });
        
        document.getElementById('showRegister')?.addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('loginContainer').style.transform = 'translateX(100%)';
            document.getElementById('loginContainer').style.opacity = '0';
            document.getElementById('registerContainer').style.transform = 'translateX(0)';
            document.getElementById('registerContainer').style.opacity = '1';
            window.history.pushState(null, '', window.location.pathname);
        });
        
        // Form validation
        document.getElementById('registerForm')?.addEventListener('submit', function(e) {
            const email = document.getElementById('regEmail').value;
            const password = document.getElementById('regPassword').value;
            
            if (!email || !password) {
                e.preventDefault();
                alert('Please fill in all fields');
                return;
            }
            
            // Email validation
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                e.preventDefault();
                alert('Please enter a valid email address');
                return;
            }
            
            // University email check (example)
            if (!email.endsWith('.edu')) {
                if (!confirm('This doesn\'t look like a university email. Are you sure you want to proceed?')) {
                    e.preventDefault();
                    return;
                }
            }
            
            // Password length check
            if (password.length < 8) {
                e.preventDefault();
                alert('Password must be at least 8 characters');
                return;
            }
        });
        
        // Initialize
        window.onload = function() {
            createTechBackground();
            setupPasswordToggle('toggleRegPassword', 'regPassword');
            setupPasswordToggle('toggleLoginPassword', 'loginPassword');
            
            // Handle back/forward navigation
            window.addEventListener('popstate', function() {
                const isLogin = window.location.search.includes('login');
                if (isLogin) {
                    document.getElementById('registerContainer').style.transform = 'translateX(-100%)';
                    document.getElementById('registerContainer').style.opacity = '0';
                    document.getElementById('loginContainer').style.transform = 'translateX(0)';
                    document.getElementById('loginContainer').style.opacity = '1';
                } else {
                    document.getElementById('loginContainer').style.transform = 'translateX(100%)';
                    document.getElementById('loginContainer').style.opacity = '0';
                    document.getElementById('registerContainer').style.transform = 'translateX(0)';
                    document.getElementById('registerContainer').style.opacity = '1';
                }
            });
        };
    </script>
</body>
</html>