<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection with error handling
try {
    $conn = new mysqli("localhost", "root", "", "task_manager", 3307);
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    // Set charset to utf8mb4 for proper encoding
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    die("Database connection error: " . $e->getMessage());
}

// Get user information
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User'; // Fallback if name not set
$user_email = $_SESSION['user_email'] ?? ''; // Fallback if email not set

// Get user courses (with proper error handling)
$courses = [];
try {
    $course_sql = "SELECT id, course_code, course_name FROM user_courses WHERE user_id = ?";
    $course_stmt = $conn->prepare($course_sql);
    
    if ($course_stmt === false) {
        throw new Exception("Error preparing course statement: " . $conn->error);
    }
    
    $course_stmt->bind_param("i", $user_id);
    if (!$course_stmt->execute()) {
        throw new Exception("Error executing course statement: " . $course_stmt->error);
    }
    
    $course_result = $course_stmt->get_result();
    while ($row = $course_result->fetch_assoc()) {
        $courses[$row['id']] = $row;
    }
    $course_stmt->close();
} catch (Exception $e) {
    error_log("Error fetching courses: " . $e->getMessage());
}

// Mark as Completed
if (isset($_GET['complete'])) {
    try {
        $task_id = intval($_GET['complete']);
        $stmt = $conn->prepare("UPDATE tasks SET status = 'Completed', completed_at = NOW() WHERE id = ? AND user_id = ?");
        
        if ($stmt === false) {
            throw new Exception("Error preparing complete statement: " . $conn->error);
        }
        
        $stmt->bind_param("ii", $task_id, $user_id);
        if (!$stmt->execute()) {
            throw new Exception("Error executing complete statement: " . $stmt->error);
        }
        $stmt->close();
        header("Location: dashboard.php");
        exit();
    } catch (Exception $e) {
        die("Error completing task: " . $e->getMessage());
    }
}

// Get stats for dashboard cards
try {
    $stats_sql = "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN status = 'Pending' AND due_date <= CURDATE() THEN 1 ELSE 0 END) as overdue,
        SUM(CASE WHEN priority = 'High' THEN 1 ELSE 0 END) as high_priority
        FROM tasks WHERE user_id = ?";
    
    $stats_stmt = $conn->prepare($stats_sql);
    
    if ($stats_stmt === false) {
        throw new Exception("Error preparing stats statement: " . $conn->error);
    }
    
    $stats_stmt->bind_param("i", $user_id);
    if (!$stats_stmt->execute()) {
        throw new Exception("Error executing stats statement: " . $stats_stmt->error);
    }
    
    $stats_result = $stats_stmt->get_result();
    $stats = $stats_result->fetch_assoc();
    $stats_stmt->close();
    
    // Ensure all stats have values even if NULL
    $stats = array_map(function($value) {
        return $value !== null ? $value : 0;
    }, $stats);
    
} catch (Exception $e) {
    // Don't die on stats error - just show zeros and continue
    $stats = [
        'total' => 0,
        'completed' => 0,
        'overdue' => 0,
        'high_priority' => 0
    ];
    error_log("Error getting stats: " . $e->getMessage());
}

// Rest of your code remains the same...
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | StudySphere</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Orbitron:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #6C63FF;
            --primary-dark: #5649F0;
            --secondary: #FF6584;
            --accent: #42D7D6;
            --tech-blue: #0EA5E9;
            --tech-purple: #8B5CF6;
            --tech-pink: #EC4899;
            --dark: #1E293B;
            --light: #F8FAFC;
            --success: #10B981;
            --warning: #F59E0B;
            --danger: #EF4444;
            --gray: #94A3B8;
            --dark-bg: #0F172A;
            --card-bg: rgba(255, 255, 255, 0.05);
            --card-border: rgba(255, 255, 255, 0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--dark-bg);
            color: var(--light);
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* Tech Background Elements */
        .tech-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }
        
        .circuit-node {
            position: absolute;
            border-radius: 50%;
            background: rgba(110, 231, 183, 0.1);
            border: 1px solid rgba(110, 231, 183, 0.3);
            animation: pulse 4s infinite alternate;
        }
        
        .circuit-line {
            position: absolute;
            background: linear-gradient(90deg, rgba(110, 231, 183, 0.3), transparent);
            transform-origin: left center;
            height: 1px;
        }
        
        .floating-icon {
            position: absolute;
            opacity: 0.1;
            font-size: 2rem;
            animation: float 15s infinite linear;
        }
        
        @keyframes float {
            0% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-50px) rotate(180deg); }
            100% { transform: translateY(0) rotate(360deg); }
        }
        
        @keyframes pulse {
            0% { transform: scale(1); opacity: 0.3; }
            100% { transform: scale(1.2); opacity: 0.6; }
        }
        
        /* Main Layout */
        .dashboard-container {
            display: grid;
            grid-template-columns: 250px 1fr;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(10px);
            border-right: 1px solid var(--card-border);
            padding: 20px;
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--card-border);
        }
        
        .logo-icon {
            width: 40px;
            height: 40px;
            background: var(--primary);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
        }
        
        .logo-text {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.5rem;
            font-weight: 600;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: 1px;
        }
        
        .nav-menu {
            list-style: none;
            margin-bottom: 30px;
        }
        
        .nav-item {
            margin-bottom: 8px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 8px;
            color: var(--gray);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover, .nav-link.active {
            background: var(--primary);
            color: white;
        }
        
        .nav-link i {
            margin-right: 10px;
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }
        
        .courses-title {
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--gray);
            margin: 25px 0 15px;
            padding-left: 15px;
        }
        
        .course-item {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .course-item:hover {
            background: rgba(255, 255, 255, 0.05);
        }
        
        .course-color {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 10px;
            flex-shrink: 0;
        }
        
        .course-name {
            font-size: 0.9rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        /* Main Content */
        .main-content {
            padding: 30px;
            overflow-y: auto;
            max-height: 100vh;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            font-weight: 600;
            color: white;
        }
        
        .user-info h3 {
            font-size: 1.2rem;
            margin-bottom: 2px;
        }
        
        .user-info p {
            font-size: 0.8rem;
            color: var(--gray);
        }
        
        .quick-actions {
            display: flex;
            gap: 15px;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
        }
        
        .btn i {
            margin-right: 8px;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(108, 99, 255, 0.3);
        }
        
        .btn-outline {
            background: transparent;
            color: var(--gray);
            border: 1px solid var(--card-border);
        }
        
        .btn-outline:hover {
            background: rgba(255, 255, 255, 0.05);
            color: white;
        }
        
        /* Dashboard Grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(12, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background: var(--card-bg);
            backdrop-filter: blur(10px);
            border: 1px solid var(--card-border);
            border-radius: 12px;
            padding: 20px;
            transition: all 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .card-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: white;
        }
        
        .card-actions {
            display: flex;
            gap: 10px;
        }
        
        .card-actions .btn {
            padding: 5px 10px;
            font-size: 0.8rem;
        }
        
        /* Stats Cards */
        .stat-card {
            grid-column: span 3;
            text-align: center;
        }
        
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 5px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: var(--gray);
        }
        
        /* Focus Card */
        .focus-card {
            grid-column: span 4;
            background: linear-gradient(135deg, rgba(108, 99, 255, 0.2), rgba(66, 215, 214, 0.2));
            position: relative;
            overflow: hidden;
        }
        
        .focus-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
            z-index: 1;
        }
        
        .focus-content {
            position: relative;
            z-index: 2;
        }
        
        .pomodoro-timer {
            font-size: 3rem;
            font-weight: 700;
            text-align: center;
            margin: 20px 0;
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 2px;
        }
        
        .timer-controls {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .current-task {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        
        /* Tasks Cards */
        .tasks-card {
            grid-column: span 4;
        }
        
        .task-list {
            list-style: none;
        }
        
        .task-item {
            padding: 12px 0;
            border-bottom: 1px solid var(--card-border);
            display: flex;
            align-items: center;
        }
        
        .task-item:last-child {
            border-bottom: none;
        }
        
        .task-checkbox {
            margin-right: 12px;
            width: 18px;
            height: 18px;
            accent-color: var(--primary);
        }
        
        .task-content {
            flex-grow: 1;
        }
        
        .task-title {
            font-weight: 500;
            margin-bottom: 3px;
        }
        
        .task-meta {
            display: flex;
            align-items: center;
            font-size: 0.8rem;
            color: var(--gray);
        }
        
        .priority-badge {
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 50px;
            margin-right: 8px;
        }
        
        .priority-badge.high {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
        }
        
        .priority-badge.medium {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning);
        }
        
        .priority-badge.low {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }
        
        .course-badge {
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 50px;
            color: white;
            margin-right: 8px;
        }
        
        /* Study Analytics */
        .analytics-card {
            grid-column: span 8;
        }
        
        .chart-container {
            height: 250px;
            margin-top: 20px;
        }
        
        /* Recent Activity */
        .activity-card {
            grid-column: span 4;
        }
        
        .activity-item {
            display: flex;
            padding: 12px 0;
            border-bottom: 1px solid var(--card-border);
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: rgba(108, 99, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            color: var(--primary);
            flex-shrink: 0;
        }
        
        .activity-content {
            flex-grow: 1;
        }
        
        .activity-title {
            font-weight: 500;
            margin-bottom: 3px;
        }
        
        .activity-meta {
            font-size: 0.8rem;
            color: var(--gray);
        }
        
        /* Responsive Design */
        @media (max-width: 1200px) {
            .dashboard-grid {
                grid-template-columns: repeat(6, 1fr);
            }
            
            .stat-card {
                grid-column: span 2;
            }
            
            .focus-card, .tasks-card, .analytics-card, .activity-card {
                grid-column: span 3;
            }
        }
        
        @media (max-width: 992px) {
            .dashboard-container {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                display: none; /* Will be replaced with mobile menu */
            }
        }
        
        @media (max-width: 768px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .stat-card, .focus-card, .tasks-card, .analytics-card, .activity-card {
                grid-column: span 1;
            }
            
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .quick-actions {
                width: 100%;
                justify-content: space-between;
            }
        }
    </style>
</head>
<body>
    <!-- Tech Background Elements -->
    <div class="tech-bg" id="techBg"></div>
    
    <!-- Dashboard Layout -->
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="logo">
                <div class="logo-icon">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <div class="logo-text">StudySphere</div>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link active">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="tasks.php" class="nav-link">
                        <i class="fas fa-tasks"></i>
                        <span>My Tasks</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="courses.php" class="nav-link">
                        <i class="fas fa-book"></i>
                        <span>Courses</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="study-sessions.php" class="nav-link">
                        <i class="fas fa-clock"></i>
                        <span>Study Sessions</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="grades.php" class="nav-link">
                        <i class="fas fa-chart-line"></i>
                        <span>Grades</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="resources.php" class="nav-link">
                        <i class="fas fa-folder"></i>
                        <span>Resources</span>
                    </a>
                </li>
            </ul>
            
            <h4 class="courses-title">My Courses</h4>
            <div class="courses-list">
                <?php foreach ($courses as $course): ?>
                <div class="course-item">
                    <div class="course-color" style="background: <?= ['#6C63FF', '#FF6584', '#42D7D6', '#8B5CF6', '#EC4899'][$course['id'] % 5] ?>"></div>
                    <div class="course-name"><?= htmlspecialchars($course['course_code']) ?></div>
                </div>
                <?php endforeach; ?>
                <a href="courses.php" class="btn btn-outline" style="width: 100%; margin-top: 10px;">
                    <i class="fas fa-plus"></i> Add Course
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <div class="header">
                <div class="user-profile">
                    <div class="user-avatar"><?= strtoupper(substr($user_name, 0, 1)) ?></div>
                    <div class="user-info">
                        <h3>Welcome back, <?= htmlspecialchars($user_name) ?></h3>
                        <p><?= htmlspecialchars($user_email) ?></p>
                    </div>
                </div>
                
                <div class="quick-actions">
                    <button class="btn btn-outline">
                        <i class="fas fa-calendar"></i> Calendar
                    </button>
                    <button class="btn btn-outline">
                        <i class="fas fa-bell"></i> Notifications
                    </button>
                    <a href="add-task.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i> New Task
                    </a>
                </div>
            </div>
            
            <!-- Dashboard Grid -->
            <div class="dashboard-grid">
                <!-- Stats Cards -->
                <div class="card stat-card">
                    <div class="stat-number"><?= $stats['total'] ?></div>
                    <div class="stat-label">Total Tasks</div>
                    <i class="fas fa-tasks" style="font-size: 2rem; opacity: 0.1; margin-top: 10px;"></i>
                </div>
                
                <div class="card stat-card">
                    <div class="stat-number"><?= $stats['completed'] ?></div>
                    <div class="stat-label">Completed</div>
                    <i class="fas fa-check-circle" style="font-size: 2rem; opacity: 0.1; margin-top: 10px;"></i>
                </div>
                
                <div class="card stat-card">
                    <div class="stat-number"><?= $stats['overdue'] ?></div>
                    <div class="stat-label">Overdue</div>
                    <i class="fas fa-exclamation-triangle" style="font-size: 2rem; opacity: 0.1; margin-top: 10px;"></i>
                </div>
                
                <div class="card stat-card">
                    <div class="stat-number"><?= $stats['high_priority'] ?></div>
                    <div class="stat-label">High Priority</div>
                    <i class="fas fa-flag" style="font-size: 2rem; opacity: 0.1; margin-top: 10px;"></i>
                </div>
                
                <!-- Focus Card -->
                <div class="card focus-card">
                    <div class="focus-content">
                        <div class="card-header">
                            <h3 class="card-title">Focus Mode</h3>
                            <div class="card-actions">
                                <button class="btn btn-outline" style="color: white;">
                                    <i class="fas fa-cog"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="pomodoro-timer">25:00</div>
                        
                        <div class="timer-controls">
                            <button class="btn btn-primary">
                                <i class="fas fa-play"></i> Start
                            </button>
                            <button class="btn btn-outline" style="color: white;">
                                <i class="fas fa-forward"></i> Skip
                            </button>
                        </div>
                        
                        <div class="current-task">
                            <div class="task-meta">
                                <?= courseBadge($upcoming_tasks[0]['course_id'] ?? null, $courses) ?>
                                <?= priorityBadge($upcoming_tasks[0]['priority'] ?? 'Medium') ?>
                            </div>
                            <p><?= $upcoming_tasks[0]['title'] ?? 'No current task' ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Upcoming Tasks -->
                <div class="card tasks-card">
                    <div class="card-header">
                        <h3 class="card-title">Upcoming Tasks</h3>
                        <a href="tasks.php" class="btn btn-outline" style="padding: 5px 10px; font-size: 0.8rem;">
                            View All
                        </a>
                    </div>
                    
                    <ul class="task-list">
                        <?php if (!empty($upcoming_tasks)): ?>
                            <?php foreach ($upcoming_tasks as $task): ?>
                            <li class="task-item">
                                <input type="checkbox" class="task-checkbox">
                                <div class="task-content">
                                    <div class="task-title"><?= htmlspecialchars($task['title']) ?></div>
                                    <div class="task-meta">
                                        <?= courseBadge($task['course_id'], $courses) ?>
                                        <?= priorityBadge($task['priority']) ?>
                                        <span><?= friendlyDate($task['due_date']) ?></span>
                                    </div>
                                </div>
                                <a href="dashboard.php?complete=<?= $task['id'] ?>" class="btn btn-outline" style="padding: 5px 10px;">
                                    <i class="fas fa-check"></i>
                                </a>
                            </li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li class="task-item">
                                <div class="task-content" style="text-align: center; color: var(--gray);">
                                    <i class="fas fa-check-circle" style="font-size: 2rem; margin-bottom: 10px; display: block;"></i>
                                    No upcoming tasks
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <!-- Study Analytics -->
                <div class="card analytics-card">
                    <div class="card-header">
                        <h3 class="card-title">Study Analytics</h3>
                        <div class="card-actions">
                            <button class="btn btn-outline" style="padding: 5px 10px; font-size: 0.8rem;">
                                This Week
                            </button>
                            <button class="btn btn-outline" style="padding: 5px 10px; font-size: 0.8rem;">
                                <i class="fas fa-ellipsis-h"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="chart-container">
                        <!-- Chart would be rendered here with Chart.js -->
                        <canvas id="studyChart"></canvas>
                    </div>
                </div>
                
                <!-- Recent Activity -->
                <div class="card activity-card">
                    <div class="card-header">
                        <h3 class="card-title">Recent Activity</h3>
                        <a href="activity.php" class="btn btn-outline" style="padding: 5px 10px; font-size: 0.8rem;">
                            View All
                        </a>
                    </div>
                    
                    <div class="activity-list">
                        <?php if (!empty($completed_tasks)): ?>
                            <?php foreach ($completed_tasks as $task): ?>
                            <div class="activity-item">
                                <div class="activity-icon">
                                    <i class="fas fa-check"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-title">Completed: <?= htmlspecialchars($task['title']) ?></div>
                                    <div class="activity-meta">
                                        <?= courseBadge($task['course_id'], $courses) ?>
                                        <span><?= date('M j, g:i a', strtotime($task['completed_at'])) ?></span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="activity-item">
                                <div class="activity-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-title">No recent activity</div>
                                    <div class="activity-meta">Complete some tasks to see activity here</div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Initialize tech background
        function createTechBackground() {
            const container = document.getElementById('techBg');
            container.innerHTML = '';
            
            // Create nodes
            for (let i = 0; i < 15; i++) {
                const node = document.createElement('div');
                node.classList.add('circuit-node');
                
                // Random position
                const posX = Math.random() * 100;
                const posY = Math.random() * 100;
                node.style.left = `${posX}%`;
                node.style.top = `${posY}%`;
                
                // Random size
                const size = Math.random() * 10 + 5;
                node.style.width = `${size}px`;
                node.style.height = `${size}px`;
                
                // Random animation delay
                const delay = Math.random() * 5;
                node.style.animationDelay = `${delay}s`;
                
                container.appendChild(node);
            }
            
            // Create connecting lines (simplified for demo)
            for (let i = 0; i < 8; i++) {
                const line = document.createElement('div');
                line.classList.add('circuit-line');
                
                // Random position and angle
                const startX = Math.random() * 100;
                const startY = Math.random() * 100;
                const length = Math.random() * 15 + 5;
                const angle = Math.random() * 360;
                
                line.style.left = `${startX}%`;
                line.style.top = `${startY}%`;
                line.style.width = `${length}%`;
                line.style.transform = `rotate(${angle}deg)`;
                
                // Random animation
                const duration = Math.random() * 5 + 3;
                line.style.animation = `pulse ${duration}s infinite alternate`;
                
                container.appendChild(line);
            }
        }
        
        // Initialize study chart
        function initStudyChart() {
            const ctx = document.getElementById('studyChart').getContext('2d');
            
            // Sample data - in a real app this would come from PHP/DB
            const studyData = {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Study Time (hours)',
                    data: [2.5, 3, 1.75, 2.25, 4, 1.5, 0.5],
                    backgroundColor: 'rgba(108, 99, 255, 0.2)',
                    borderColor: 'rgba(108, 99, 255, 1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                }]
            };
            
            new Chart(ctx, {
                type: 'line',
                data: studyData,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: 'rgba(255, 255, 255, 0.7)'
                            }
                        },
                        x: {
                            grid: {
                                color: 'rgba(255, 255, 255, 0.1)'
                            },
                            ticks: {
                                color: 'rgba(255, 255, 255, 0.7)'
                            }
                        }
                    }
                }
            });
        }
        
        // Initialize everything when DOM is loaded
        document.addEventListener('DOMContentLoaded', function() {
            createTechBackground();
            initStudyChart();
            
            // Add animation to cards
            const cards = document.querySelectorAll('.card');
            cards.forEach((card, index) => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = `all 0.3s ease ${index * 0.1}s`;
                
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 50);
            });
        });
    </script>
</body>
</html>