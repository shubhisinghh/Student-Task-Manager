<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "task_manager", 3307);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$success_message = '';
$error_message = '';

// When form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $due_date = $_POST['due_date'];
    $status = "Pending";
    $priority = $_POST['priority'];

    // Validate due date is not in the past
    $today = date("Y-m-d");
    if ($due_date < $today) {
        $error_message = "❌ Due date cannot be in the past";
    } else {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO tasks (user_id, title, description, due_date, status, priority) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $user_id, $title, $description, $due_date, $status, $priority);

        if ($stmt->execute()) {
            $success_message = "✅ Task added successfully!";
            // Clear form fields if needed
            $title = $description = $due_date = '';
        } else {
            $error_message = "❌ Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Task | Task Manager</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --danger-color: #f72585;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
            --border-radius: 8px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: var(--dark-color);
            line-height: 1.6;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }

        .header h2 {
            color: var(--primary-color);
            font-weight: 600;
        }

        .back-link {
            color: var(--gray-color);
            text-decoration: none;
            font-size: 14px;
            transition: var(--transition);
        }

        .back-link:hover {
            color: var(--primary-color);
        }

        .back-link i {
            margin-right: 5px;
        }

        .alert {
            padding: 12px 15px;
            border-radius: var(--border-radius);
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-success {
            background-color: rgba(76, 201, 240, 0.2);
            color: #0a6c74;
            border-left: 4px solid var(--success-color);
        }

        .alert-danger {
            background-color: rgba(247, 37, 133, 0.2);
            color: #a4133c;
            border-left: 4px solid var(--danger-color);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-family: inherit;
            font-size: 15px;
            transition: var(--transition);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }

        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }

        .select-wrapper {
            position: relative;
        }

        .select-wrapper::after {
            content: '\f078';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            color: var(--gray-color);
            pointer-events: none;
        }

        select.form-control {
            appearance: none;
            padding-right: 40px;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: var(--border-radius);
            font-family: inherit;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
        }

        .btn:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
        }

        .btn-block {
            display: block;
            width: 100%;
        }

        .date-picker-wrapper {
            position: relative;
        }

        .date-picker-wrapper i {
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            color: var(--gray-color);
        }

        @media (max-width: 768px) {
            .container {
                margin: 20px;
                padding: 20px;
            }
        }

        /* Animation for success message */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
            animation: fadeIn 0.3s ease-out;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2><i class="fas fa-plus-circle"></i> Add New Task</h2>
            <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>

        <?php if ($success_message): ?>
            <div class="alert alert-success fade-in">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-danger fade-in">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" id="taskForm">
            <div class="form-group">
                <label for="title"><i class="fas fa-heading"></i> Task Title</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo isset($title) ? htmlspecialchars($title) : ''; ?>" required placeholder="Enter task title...">
            </div>

            <div class="form-group">
                <label for="description"><i class="fas fa-align-left"></i> Description</label>
                <textarea class="form-control" id="description" name="description" placeholder="Enter task description..."><?php echo isset($description) ? htmlspecialchars($description) : ''; ?></textarea>
            </div>

            <div class="form-group">
                <label for="due_date"><i class="fas fa-calendar-alt"></i> Due Date</label>
                <div class="date-picker-wrapper">
                    <input type="date" class="form-control" id="due_date" name="due_date" value="<?php echo isset($due_date) ? $due_date : ''; ?>" required min="<?php echo date('Y-m-d'); ?>">
                    <i class="fas fa-calendar-day"></i>
                </div>
            </div>

            <div class="form-group">
                <label for="priority"><i class="fas fa-exclamation-circle"></i> Priority</label>
                <div class="select-wrapper">
                    <select class="form-control" id="priority" name="priority" required>
                        <option value="High" <?php echo (isset($priority) && $priority == 'High') ? 'selected' : ''; ?>>High Priority</option>
                        <option value="Medium" <?php echo (!isset($priority) || $priority == 'Medium') ? 'selected' : ''; ?>>Medium Priority</option>
                        <option value="Low" <?php echo (isset($priority) && $priority == 'Low') ? 'selected' : ''; ?>>Low Priority</option>
                    </select>
                </div>
            </div>

            <button type="submit" class="btn btn-block">
                <i class="fas fa-plus"></i> Add Task
            </button>
        </form>
    </div>

    <script>
        // Simple client-side validation
        document.getElementById('taskForm').addEventListener('submit', function(e) {
            const title = document.getElementById('title').value.trim();
            const dueDate = document.getElementById('due_date').value;
            
            if (!title) {
                alert('Please enter a task title');
                e.preventDefault();
                return;
            }
            
            const today = new Date().toISOString().split('T')[0];
            if (dueDate < today) {
                alert('Due date cannot be in the past');
                e.preventDefault();
                return;
            }
        });

        // Add character counter for description
        const description = document.getElementById('description');
        const charCounter = document.createElement('small');
        charCounter.style.display = 'block';
        charCounter.style.textAlign = 'right';
        charCounter.style.marginTop = '5px';
        charCounter.style.color = '#6c757d';
        charCounter.textContent = '0/500 characters';
        description.parentNode.appendChild(charCounter);

        description.addEventListener('input', function() {
            const currentLength = this.value.length;
            charCounter.textContent = `${currentLength}/500 characters`;
            
            if (currentLength > 500) {
                charCounter.style.color = 'var(--danger-color)';
            } else {
                charCounter.style.color = 'var(--gray-color)';
            }
        });
    </script>
</body>
</html>